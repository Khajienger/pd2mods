if RequiredScript == "lib/tweak_data/charactertweakdata" then
	intimsp_o_tweakdata_init = intimsp_o_tweakdata_init or CharacterTweakData.init
	function CharacterTweakData:init(tweak_data)
		intimsp_o_tweakdata_init(self, tweak_data)
		for _,unit in pairs(self) do
			if type(unit) == "table" and unit.priority_shout then 
				unit.priority_shout = nil 
				unit.surrender = self.presets.surrender.easy
			end
		end
	end
elseif RequiredScript == "lib/units/enemies/cop/copbrain" then
	intimsp_o_copbrain_post_init = intimsp_o_copbrain_post_init or CopBrain.post_init
	function CopBrain:post_init()
		intimsp_o_copbrain_post_init(self)
		if not self._logics.intimidated then self._logics.intimidated = CopLogicIntimidated end
		if not self._logics.flee then self._logics.flee = CopLogicFlee end
	end
	intimsp_o_convert_to_criminal = intimsp_o_convert_to_criminal or CopBrain.convert_to_criminal
	function CopBrain:convert_to_criminal(mastermind_criminal)
		intimsp_o_convert_to_criminal(self, mastermind_criminal)
		local category = self._unit:base()._tweak_table
		local groupai = managers.groupai:state()
		if groupai._special_units[category] then groupai._special_units[category][self._unit:key()] = nil end
	end
elseif RequiredScript == "lib/managers/playermanager" then
	intimsp_o_has_upgrade = intimsp_o_has_upgrade or PlayerManager.has_category_upgrade
	function PlayerManager:has_category_upgrade(category, upgrade)
		return upgrade == "intimidate_specials" or intimsp_o_has_upgrade(self, category, upgrade)
	end
end