if RequiredScript == "lib/tweak_data/levelstweakdata" then
    local bagsforlyfe = LevelsTweakData.init
    function LevelsTweakData:init(...)
        bagsforlyfe(self)
        for _,heist in pairs(self) do
            if type(heist.max_bags) == "number" then
                heist.max_bags = 900
            end
        end
    end
end