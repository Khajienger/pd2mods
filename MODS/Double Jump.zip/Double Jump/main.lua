function infomsg(msg) managers.chat:_receive_message(1, "INFO", msg, Color(255, 255, 212, 0) / 255, false) end

local orig_update_foley = PlayerStandard._update_foley
function PlayerStandard:_update_foley(t, input)
    if self._gnd_ray then
        Global.has_extra_jump = true
    end
	orig_update_foley(self, t, input)
end

function PlayerStandard:_check_action_jump(t, input)
    local vanilla_jmp_interval = 0.55
    local mario_jmp_interval = 0.22
    local jmp_interval = vanilla_jmp_interval 
    if Global.has_extra_jump then
        jmp_interval = mario_jmp_interval
    end
	local new_action = nil
	local action_wanted = input.btn_jump_press

	if action_wanted then
		local action_forbidden = self._jump_t and t < self._jump_t + jmp_interval
		action_forbidden = action_forbidden or self._unit:base():stats_screen_visible() or self:_interacting() or self:_on_zipline() or self:_does_deploying_limit_movement() or self:_is_using_bipod()
        if not Global.has_extra_jump then
            action_forbidden = action_forbidden or self._state_data.in_air
        end

		if not action_forbidden then
			if self._state_data.ducking then
				self:_interupt_action_ducking(t)
			else
				if self._state_data.on_ladder then
					self:_interupt_action_ladder(t)
				end

				local action_start_data = {}
				local jump_vel_z = tweak_data.player.movement_state.standard.movement.jump_velocity.z
				action_start_data.jump_vel_z = jump_vel_z

				if self._move_dir then
					local is_running = self._running and self._unit:movement():is_above_stamina_threshold() and t - self._start_running_t > 0.4
					local jump_vel_xy = tweak_data.player.movement_state.standard.movement.jump_velocity.xy[is_running and "run" or "walk"]
					action_start_data.jump_vel_xy = Global.has_extra_jump and tweak_data.player.movement_state.standard.movement.jump_velocity.xy["run"] or jump_vel_xy

					if is_running then
						self._unit:movement():subtract_stamina(tweak_data.player.movement_state.stamina.JUMP_STAMINA_DRAIN)
					end
				end

				if Global.has_extra_jump then
                    Global.has_extra_jump = false
					Global.last_jump_was_normal_jump = false
                else
					Global.last_jump_was_normal_jump = true
				end
				new_action = self:_start_action_jump(t, action_start_data)
			end
		end
	end

	return new_action
end

function PlayerStandard:_update_network_jump(pos, is_exit)
	local mover = self._unit:mover()

	if self._is_jumping and (is_exit or not mover or mover:standing() and mover:velocity().z < 0 or mover:gravity().z == 0) then
		if not self._is_jump_middle_passed then
			self._is_jump_middle_passed = true
		end

		self._is_jumping = nil
	elseif self._send_jump_vec and not is_exit then
		if self._is_jumping and type(self._gnd_ray) ~= "boolean" then
			self._ext_network:send("action_walk_nav_point", self._gnd_ray and self._gnd_ray.position)
		end

		if Global.last_jump_was_normal_jump then
			self._ext_network:send("action_jump", pos or self._pos, self._send_jump_vec)
		end

		self._send_jump_vec = nil
		self._is_jumping = true
		self._is_jump_middle_passed = nil

		mvector3.set(self._last_sent_pos, pos or self._pos)
	elseif self._is_jumping and not self._is_jump_middle_passed and mover and mover:velocity().z < 0 then
		self._is_jump_middle_passed = true
	end
end