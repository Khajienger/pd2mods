local old_init = PlayerTweakData.init

function PlayerTweakData:init()
	old_init(self)
	
	self.alarm_pager = {
		first_call_delay = {2, 4},
		call_duration = {
			{240, 240},
			{240, 240}
		},
		nr_of_calls = {2, 2},
		bluff_success_chance = {
			1,
			1,
			1,
			
			1,
			1,
			1,
			
			1,
			1,
			1,
			
			1,
			1,
			1,
			
			1,
			1,
			1,
			
			1,
			1,
			1
		},
		bluff_success_chance_w_skill = {
			1,
			1,
			1,
			
			1,
			1,
			1,
			
			1,
			1,
			1,
			
			1,
			1,
			1,
			
			1,
			1,
			1,
			
			1,
			1,
			1
                        
		}
	}
end