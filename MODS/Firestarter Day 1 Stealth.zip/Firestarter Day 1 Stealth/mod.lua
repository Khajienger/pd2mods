if Network:is_client() then
	return
end

if not Global.game_settings or Global.game_settings.level_id ~= 'firestarter_1' or Global.game_settings.gamemode == 'crime_spree' then
	return
end

core:module("CoreMissionScriptElement")
core:import("CoreXml")
core:import("CoreCode")
core:import("CoreClass")

MissionScriptElement = MissionScriptElement or class()
local override_func = MissionScriptElement.on_executed

function MissionScriptElement:on_executed(...)
	if tostring(self._id) == '100943' then
		self._values.enabled = false
	end
	override_func(self, ...)
end