local index=1
local _enter=IngameAccessCamera.at_enter
local _update=IngameAccessCamera.update

function IngameAccessCamera:at_enter(...)
	_enter(self, ...)
	for i, cam in ipairs(self._cameras) do
		if i~=self._camera_data.index then
			self:vis_on_cam(cam.access_camera)
			end
		end
	end

function IngameAccessCamera:update(...)
	_update(self, ...)
	index=index >= #self._cameras and 1 or index+1
	if index~=self._camera_data.index then
		self:vis_on_cam(self._cameras[index].access_camera)
		end
	end

function IngameAccessCamera:vis_on_cam(cam)
	if cam and cam:has_camera_unit() and not cam:value("destroyed") then
		local units=World:find_units_quick("all", 3, 16, 21, managers.slot:get_mask("enemies"))
		self._cam_unit:set_position(cam:camera_position())
		for i, unit in ipairs(units) do
			if not self._cam_unit:raycast("ray", unit:movement():m_head_pos(), cam:camera_position(), "ray_type", "ai_vision", "slot_mask", managers.slot:get_mask("world_geometry"), "report") then
				if managers.player:upgrade_value("player", "sec_camera_highlight", false) and unit:base()._tweak_table and (managers.groupai:state():whisper_mode() and tweak_data.character[unit:base()._tweak_table].silent_priority_shout or tweak_data.character[unit:base()._tweak_table].priority_shout) then
					managers.game_play_central:auto_highlight_enemy(unit, true)
					end
				end
			end
		self._cam_unit:set_position(self._last_access_camera:camera_position())
		end
	end