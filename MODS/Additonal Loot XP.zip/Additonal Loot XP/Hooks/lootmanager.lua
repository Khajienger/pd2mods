local level = Global.level_data and Global.level_data.level_id or ""

local heist_xp = {
  branchbank = 8003, -- Bank Heist
  jewelry_store = 8003, -- Jewelry Store
  firestarter_1 = 5003, -- Firestarter day 1
  firestarter_3 = 5003, -- Firestarter day 3
  watchdogs_1 = 5003, -- Watchdogs day 1
  alex_2 = 5003, -- Rats day 2
  alex_3 = 9003, -- Rats day 3
  welcome_to_the_jungle_1 = 8003, -- Big Oil day 1
  welcome_to_the_jungle_1_night = 8003, -- Big Oil day 1 - night
  election_day_2 = 9003, -- Election Day day 2 (Swing Vote)
  election_day_3 = 9003, -- Election Day day 2 (Breaking Ballot)
  mallcrasher = 9003, -- Mallcrasher
  ukrainian_job = 15003, -- Ukrainian Job
  four_stores = 18003, -- Four Stores
  kenaz = 9003, -- Golden Grin Casino
  pex = 17003, -- Breakfast in Tijuana
  short1 = 18003, -- Flash Drive
  short2 = 18003, -- Get the Coke
  escape_cafe = 5003, -- Cafe Escape
  escape_cafe_day = 5003, -- Cafe Escape
  escape_garage = 5003, -- Garage Escape
  escape_overpass = 5003, -- Overpass Escape
  escape_park = 5003, -- Park Escape
  escape_park_day = 5003, -- Park Escape
  escape_street = 5003, -- Street Escape
}
local bag_spec_xp = {
  dinner = { din_pig = 18003 }, -- Slaughterhouse
  family = { money = 18003 }, -- Diamond Store
  flat = { toothbrush = 18003 }, -- Panic Room
  framing_frame_3 = { old_wine = 18003 }, -- Framing Frame day 3
}
local bag_limit_xp = { 
  kosugi = { limit = 384, xp = 9003 },
  mia_2 = { limit = 384, xp = 18003 },
  chas = { limit = 384, xp = 18003 },
}
local small_loot_xp = {
  gen_atm = 3003, -- ATM, Money Counter
  slot_machine_payout = 5003, -- Winning Slip
  spawn_bucket_of_money = 5003, -- Au Ticket
  ring_band = 703, -- ??? Ring
  federali_medal = 703, -- Federali Medal
  money_bundle = 403, -- Money Bundle, Casino Chips, Phone, Tablet
  diamondheist_vault_bust = 403, -- Necklace
  diamondheist_vault_diamond = 403, -- Jewelry, Jewels
  diamondheist_big_diamond = 403, -- Saphire, Tiara
  mus_small_artifact = 403, -- Small Artifact
  vault_loot_chest = 403, -- Chest
  vault_loot_diamond_chest = 403, -- Diamond Chest
  vault_loot_banknotes = 403, -- Banknotes
  vault_loot_silver = 403, -- Silver
  vault_loot_diamond_collection = 403, -- Diamond Collection
  vault_loot_trophy = 403, -- Trophy
  vault_loot_gold = 403, -- Gold Bar
  vault_loot_cash = 403, -- Money Roll
  vault_loot_coins = 403, -- Coins
  vault_loot_ring = 403, -- Ring
  vault_loot_jewels = 403, -- Diamonds
}
local last_timestamp = 0

Hooks:PostHook(LootManager, "sync_secure_loot", "AddLootXP_LM_sync_secure_loot", function(self, carry_id, multiplier_level, silent, peer_id)
  if tweak_data.carry[carry_id] then
    local add_xp = heist_xp[level] or bag_spec_xp[level] and bag_spec_xp[level][carry_id] or 0

    if bag_limit_xp[level] then
      local secured = self:get_secured_mandatory_bags_amount() + self:get_secured_bonus_bags_amount()
      add_xp = secured > bag_limit_xp[level].limit and bag_limit_xp[level].xp or add_xp
    end

    managers.experience:mission_xp_award(add_xp)
  else
    local add_xp = small_loot_xp[carry_id] or 0
    local my_id = managers.network:session():local_peer():id()
    local cur_time = TimerManager:game():time()

    if Network:is_client() and peer_id == my_id and last_timestamp == cur_time then
      add_xp = 0
    end

    last_timestamp = cur_time
    managers.experience:mission_xp_award(add_xp)
  end
end)