local class_name = "g_dodge_counter"
local req_script = table.remove(RequiredScript:split("/"))

if not rawget(_G, class_name) then
	rawset(_G, class_name, {})
end
 
local c = _G[class_name]

function c:can_dodge(unit)
	unit = unit and unit:key() and unit:key() == managers.player:player_unit():key() and managers.player:player_unit()
	if unit and alive(unit) then
		local armor_dodge_chance = managers.player:body_armor_value("dodge")
		local skill_dodge_chance = managers.player:skill_dodge_chance(unit:movement():running(), unit:movement():crouching(), unit:movement():zipline_unit())
		
		local dodge_roll = math.random()
		local dodge_value = tweak_data.player.damage.DODGE_INIT or 0
		dodge_value = dodge_value + armor_dodge_chance + skill_dodge_chance
		
		local player_dmg = unit:character_damage()
		if player_dmg and player_dmg._temporary_dodge_t and TimerManager:game():time() < player_dmg._temporary_dodge_t then
			dodge_value = dodge_value + player_dmg._temporary_dodge
		end
		
		local smoke_dodge = 0
		for _, smoke_screen in ipairs(managers.player._smoke_screen_effects or {}) do
			if smoke_screen:is_in_smoke(unit) then
				smoke_dodge = tweak_data.projectiles.smoke_screen_grenade.dodge_chance
				break
			end
		end
		
		dodge_value = 1 - (1 - dodge_value) * (1 - smoke_dodge)

		if dodge_roll < dodge_value then
			return true
		end
	end
end

if string.lower(req_script) == string.lower("playertased") then
	local orig_func_enter = PlayerTased.enter
	function PlayerTased:enter(state_data, enter_data)
		if c:can_dodge(self._unit) then
			PlayerTased.super.enter( self, state_data, enter_data )
			self._next_shock = Application:time() + 10
			self._taser_value = 1
			self._recover_delayed_clbk = "PlayerTased_recover_delayed_clbk"
			managers.enemy:add_delayed_clbk( self._recover_delayed_clbk, callback( self, self, "clbk_exit_to_std" ), Application:time() )
		else
			orig_func_enter(self, state_data, enter_data)
		end
	end
elseif string.lower(req_script) == string.lower("playermovement") then	
	local orig_func_on_SPOOCed = PlayerMovement.on_SPOOCed
	function PlayerMovement:on_SPOOCed(enemy_unit)
		if managers.player:has_category_upgrade("player", "counter_strike_spooc") and c:can_dodge(self._unit) then
			return "countered"
		else
			orig_func_on_SPOOCed(self, enemy_unit)
		end
	end
end
