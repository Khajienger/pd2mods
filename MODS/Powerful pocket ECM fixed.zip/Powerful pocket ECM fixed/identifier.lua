-- Version 2
-- Use: sandboxer:allow_mod() function to check if your mod should activate.
-- Use: sandboxer:allow_mod(false, "mod is allowed!", 3) second argument will show custom hint message but only when run outside a persist function. Last argument is how long the hint message will appear.
-- Use: sandboxer:allow_mod(true) when not checking in a persistent function for best resault, since persistent checks can halt none persistent checks.

local mod_to_check = "Powerful pocket ECM"				-- Rename this to match a specified mod up to a player and notify people related or leave as is to disable join notification for players. You can also overwrite this variable using sandboxer.mod_to_check = ""
local class_name = "sandboxer"
if not rawget(_G, class_name) then
	rawset(_G, class_name, {
		bypass_identifier = false,					-- Disable sandboxer, also disables hint messages but not join messages if enabled
		notify_on_join = true,						-- Use notify_join_msg
		notify_join_msg = "detected from", 			-- This will show between mod name and player name on player detected with the mod "mod name detected from player name" e.g or false for default
		notify_color = Color("39FF14"),				-- Color of the join message or false for default
		hint_msg = "Sandboxed mods are allowed!",	-- The default message if no message is defined in sandboxer:allow_mod() argument
		update_delay = 2,							-- Time in seconds to check if mod is allowed if sandboxer:allow_mod() is used in a persistent function, else this will not be used. Lower value will increase lag.
		persist_delay = 0,
		delay = 0,
		peers_with_mod = {},
		peers_in_lobby = {},
		mod_notified = false
	})

	local c = _G[class_name]

	function c:count_table(t)
		local count = 0
		for _ in pairs(t) do 
			count = count + 1 
		end
		return count
	end

	function c:show_hint(msg, time)
		if not self.mod_notified and managers.hud and managers.hud.show_hint and Utils:IsInHeist() then
			self.mod_notified = true
			managers.hud:show_hint({time = (time or 3), text = (msg or self.hint_msg)})
		end
	end
	
	function c:check_persist()
		self.persistent = false
		if (Application:time() - self.delay) < 0.1 then
			self.persistent = true
		end
		self.delay = Application:time()
		return self.persistent
	end
	
	function c:allow_mod(force, msg, time)
		if self.bypass_identifier then
			return true
		end
		
		local singleplayer = Global.game_settings and Global.game_settings.singleplayer
		if singleplayer then
			return true
		end
		
		local persist = self:check_persist()
		if force or not persist or Application:time() >= c.persist_delay then
			c.persist_delay = Application:time() + self.update_delay
			
			local matchmake = managers.network and managers.network.matchmake and managers.network.matchmake.lobby_handler
			local filter_permissions = matchmake and matchmake:get_lobby_data() ~= nil and matchmake:get_lobby_data().permission
			local peers_got_mod = self:count_table(self.peers_with_mod) >= self:count_table(self.peers_in_lobby)
			if (filter_permissions and (tonumber(filter_permissions) == 2 or tonumber(filter_permissions) == 3)) or peers_got_mod then
				return true, (not persist and self:show_hint(msg, time) or false)
			end
			
			if not persist then
				self.mod_notified = false
			end
		end
	end
end

local c = _G[class_name]
local req_script = table.remove(RequiredScript:split("/"))
c.mod_to_check = c.mod_to_check or mod_to_check

if string.lower(req_script) == string.lower("BaseNetworkSession") and _G["BaseNetworkSession"] ~= nil then
	--remove peer on leave/disconnect client/host
	Hooks:PostHook(BaseNetworkSession, '_on_peer_removed', class_name.."1", function(self, peer, peer_id)
		if c.peers_in_lobby[peer_id] ~= nil then
			c.peers_in_lobby[peer_id] = nil
		end

		if c.peers_with_mod[peer_id] ~= nil then
			c.peers_with_mod[peer_id] = nil
		end
	end)
elseif string.lower(req_script) == string.lower("NetworkPeer") and _G["NetworkPeer"] ~= nil then
	--send
	Hooks:PostHook(NetworkPeer, "send", class_name.."2", function(self, func_name, ...)
		local local_id = managers.network:session():local_peer():id()
		if self:id() ~= local_id and func_name and func_name == "lobby_info" and c.peers_in_lobby[self:id()] == nil and self:ip_verified() then
			c.peers_in_lobby[self:id()] = self:id()
			if c.mod_to_check ~= "Sandboxer mod" then
				LuaNetworking:SendToPeer(self:id(), c.mod_to_check, tostring(local_id))
			end
		end
	end)

	--receive
	Hooks:Add("NetworkReceivedData", class_name.."3", function(peer_id, id, sender)
		if id == c.mod_to_check and c.peers_with_mod[peer_id] == nil then
			c.peers_with_mod[peer_id] = peer_id
			if c.notify_on_join and managers.chat then
				managers.chat:_receive_message(1, c.mod_to_check, string.format("'%s' %s %s.", c.mod_to_check, (c.notify_join_msg or "detected from"), managers.network:session():peer(tonumber(sender)):name()), (c.notify_color or tweak_data.system_chat_color))
			end
		end
	end)
end

--------- Version 1 

--[[
	{ "hook_id": "lib/network/matchmaking/networkaccountsteam", "script_path": "identifier.lua" },
	{ "hook_id": "lib/network/base/basenetworksession", "script_path": "identifier.lua" },
	{ "hook_id": "lib/network/base/networkmanager", "script_path": "identifier.lua" },
	{ "hook_id": "lib/managers/gameplaycentralmanager", "script_path": "identifier.lua" },
	{ "hook_id": "lib/states/ingamewaitingforplayers", "script_path": "identifier.lua" }

	The identifiers purpose is to check if a mod should be run according to modworkshop's rules.
	It will check if the game is run in singleplayer, lobby filter is private or friends only and compare total amount of players in lobby with how many have the mod.
	This works as you are client or host of the lobby.
	
	You create your identifier and mod name in mod_name and identifier found bellow in the table.
	
	To run the identifier you toggle run_identifier_after_briefing and run_identifier_in_briefing or
	run the cheatworkshop_helper:allow_mod() function, this will return true or false and will also run when the two variables are true.
	
	If your mod will run code as the identifier disallow players from using the mod,
	you will have to add your code to this function c:remove_mod()



local class_name = "cheatworkshop_helper"
local req_script = table.remove(RequiredScript:split("/"))

if not rawget(_G, class_name) then
	rawset(_G, class_name, {
		mod_name = "your mod name",
		identifier = "your unique mod identifier",
		run_identifier_after_briefing = true,		--run identifier after briefing
		run_identifier_in_briefing = true,			--run identifier in briefing

		peers_with_mod = {},
		peers_in_lobby = {},
		notify_mod_allowed = false,
		bypass_identifier = false,					--do not use identifier
		debugging = false							--prints peers_with_mod and peers_in_lobby as players join/load
	})
end
 
local c = _G[class_name]
local function_identifier = string.format("%s_%s", class_name, c.identifier)

function c:remove_mod()
	--your code here
end

function c:allow_mod()
	local matchmake = managers.network and managers.network.matchmake and managers.network.matchmake.lobby_handler
	local filter_permissions = matchmake and matchmake:get_lobby_data() ~= nil and matchmake:get_lobby_data().permission
	local peer_allows_mod = self:peer_allows_mod()
	local singleplayer = Global.game_settings and Global.game_settings.singleplayer
	if self.bypass_identifier or (singleplayer or (filter_permissions and tonumber(filter_permissions) == 2 or tonumber(filter_permissions) == 3) or peer_allows_mod) then
		return true
	end
end

function c:show_hint(toggle)
	if toggle ~= self.notify_mod_allowed then
		self.notify_mod_allowed = toggle
		
		if managers.hud and managers.hud.show_hint then
			local toggle_s = toggle and "Activated" or "Deactivated"
			local string_f = string.format("%s %s", self.mod_name, toggle_s)
			managers.hud:show_hint({text = string_f})
		end
		
		if not toggle then
			self:remove_mod()
		end
	end
end

function c:remove_peer(peer_id)
	if self.peers_in_lobby[peer_id] ~= nil then
		self.peers_in_lobby[peer_id] = nil
	end

	if self.peers_with_mod[peer_id] ~= nil then
		self.peers_with_mod[peer_id] = nil
	end
end

function c:add_peer_to_mod(peer_id)
	if self.peers_with_mod[peer_id] == nil then
		self.peers_with_mod[peer_id] = peer_id
	end
end

function c:add_peer_to_lobby(peer_id)
	if self.peers_in_lobby[peer_id] == nil then
		self.peers_in_lobby[peer_id] = peer_id
	end
end

function c:count_table(t)
	local count = 0
	for _ in pairs(t) do 
		count = count + 1 
	end
	return count
end

function c:peer_allows_mod()
	local session = managers.network and managers.network:session()
	local local_id = session and session:local_peer() and session:local_peer():id()
	if session and local_id then
		for x = 1, 4 do
			if session:peer(x) and local_id ~= x then
				self:add_peer_to_lobby(x)
			end
		end
	end
	
	if self.debugging then
		for k, v in pairs(self.peers_in_lobby) do
			if v and managers.mission and managers.mission._fading_debug_output then
				managers.mission._fading_debug_output:script().log(string.format("%s/%s %s %s", k, v, self:count_table(self.peers_in_lobby), self:count_table(self.peers_with_mod)), Color.green)
			end
		end
	end
	
	if self:count_table(self.peers_in_lobby) > self:count_table(self.peers_with_mod) then
		return false, self:show_hint(false)
	end
	return true, self:show_hint(true)
end

function c:peer_got_mod(peer, peer_id, host)
	DelayedCalls:Add("on_load_complete_host"..tostring(peer._user_id or math.random()), 10, function()
		local user = peer:ip_verified() and Steam:user(peer:ip())
		if user then
			if user:rich_presence(self.identifier) == "1" then
				self:add_peer_to_mod(peer_id)
				
				if host then
					managers.chat:feed_system_message(ChatManager.GAME, string.format("%s also got '%s' mod installed!", peer:name(), self.mod_name))
				else
					managers.chat:feed_system_message(ChatManager.GAME, string.format("'%s' detected from %s.", self.mod_name, peer:name()))
				end
			end
		end
	end)
end

if not c.bypass_identifier and string.lower(req_script) == string.lower("networkaccountsteam") then
	--create identifier host side
	Hooks:PostHook(NetworkAccountSTEAM, '_set_presences', function_identifier.."1", function(self)
		Steam:set_rich_presence(c.identifier, 1)
	end)
elseif not c.bypass_identifier and string.lower(req_script) == string.lower("BaseNetworkSession") then
	Hooks:PostHook(BaseNetworkSession, 'on_load_complete', function_identifier.."2", function(self, simulation)
		if not simulation then
			--create identifier client side test
			Steam:set_rich_presence(c.identifier, 1)
			
			--client side join check for identifier
			for peer_id, peer in pairs(self._peers) do
				c:peer_got_mod(peer, peer_id)
			end
		end
	end)

	--remove peer on leave/disconnect client/host
	Hooks:PostHook(BaseNetworkSession, '_on_peer_removed', function_identifier.."3", function(self, peer, peer_id)
		c:remove_peer(peer_id)
	end)
elseif not c.bypass_identifier and string.lower(req_script) == string.lower("NetworkManager") then	
	Hooks:PostHook(NetworkManager, 'on_peer_added', function_identifier.."4", function(self, peer, peer_id)
		local local_id = self:session() and self:session():local_peer() and self:session():local_peer():id()
		if peer and local_id and local_id ~= peer_id then
			c:add_peer_to_lobby(peer_id)
			
			if Network:is_server() then
				--host side check for identifier
				c:peer_got_mod(peer, peer_id, true)
			else
				--create identifier client side test
				Steam:set_rich_presence(c.identifier, 1)
			end
		end
	end)
elseif c.run_identifier_after_briefing and string.lower(req_script) == string.lower("GamePlayCentralManager") then
	Hooks:PostHook(GamePlayCentralManager, "start_heist_timer", function_identifier.."5", function(self)
		c:allow_mod()
	end)
elseif c.run_identifier_in_briefing and string.lower(req_script) == string.lower("ingamewaitingforplayers") then
	Hooks:PostHook(IngameWaitingForPlayersState, "at_enter", function_identifier.."6", function(self)
		c:allow_mod()
	end)
end--]]