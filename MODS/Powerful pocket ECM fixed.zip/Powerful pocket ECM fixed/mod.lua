--if not Global.game_settings.single_player then
	--log("You're in a online game. AutoRevive has been disabled.")
	--return
  --true log("You're playing offline/single player. Enjoy AutoRevive!")
  --end

local new_amount = 2          -- Change how many pocket ecms you can have (2 is default)
local new_cooldown = 30       -- Change how long is cooldown for next pocket ecm (100s is default)
local old_init_projectiles = BlackMarketTweakData._init_projectiles
function BlackMarketTweakData:_init_projectiles(tweak_data)
local result = old_init_projectiles(self, tweak_data)
self.projectiles.pocket_ecm_jammer.max_amount = new_amount
self.projectiles.pocket_ecm_jammer.base_cooldown = new_cooldown
return result
end

function PlayerInventory:get_jammer_time()
	local new_duration = 30        -- Change how long pocket ecm will work
	return 30 -- Match it to number line above (line 16)
	end