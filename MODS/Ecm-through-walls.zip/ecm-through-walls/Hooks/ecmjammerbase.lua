function ECMJammerBase:mark_enemy_feedback()
	local range = tweak_data.upgrades.ecm_jammer_base_range
	local detected = World:find_units_quick("sphere", self._unit:position(), range, managers.slot:get_mask("enemies"))
	for _, unit in ipairs(detected) do
		if alive(unit:body("mover_blocker")) then
			managers.chat:_receive_message(1, 'MX', 'MAARKS', Color(tostring('00ff00')))
			local col_ray = {}
			col_ray.ray = Vector3(1, 0, 0)
			col_ray.position = unit:position()
			local action_data = {}
			action_data.variant = "stun"
			action_data.damage = 0
			action_data.attacker_unit = self:owner()
			action_data.col_ray = col_ray

			unit:character_damage():damage_explosion(action_data)
		end
	end
end

local retrigger = 0
local old_update = ECMJammerBase.update
function ECMJammerBase:update(unit, t, dt)
	old_update(self, unit, t, dt)
	if self._feedback_active then
		retrigger = retrigger - dt
		if retrigger <= 0 then
			self:mark_enemy_feedback()	
			retrigger = 3
		end
	end
	
end