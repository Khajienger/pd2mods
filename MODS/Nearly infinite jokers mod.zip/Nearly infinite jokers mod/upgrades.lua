local init_original = UpgradesTweakData.init

function UpgradesTweakData:init(...)
    init_original(self, ...)

    self.values.player.convert_enemies_max_minions = {
        2,
        1000
    }
end