_G.TacticReloadSettings = _G.TacticReloadSettings or {}
TacticReloadSettings.path = ModPath
TacticReloadSettings.data_path = SavePath .. 'mtac_fixed.txt'
TacticReloadSettings.settings = {
	pistol = false,
	akimbo = false,
	smg = true,
	bow = false,
	crossbow = false,
	shotgun = true,
	assault_rifle = true,
	snp = false,
	lmg = true,
	minigun = true,
	grenade_launcher = false,
	flamethrower = true,
	saw = false
}

function TacticReloadSettings:load()
	local configfile = io.open( self.data_path, 'r' )
	if configfile then
		for k, v in pairs( json.decode(configfile:read('*all')) or {} ) do
			self.settings[k] = v
		end
		configfile:close()
	end
end

function TacticReloadSettings:save()
	local configfile = io.open(self.data_path, 'w+')
	if configfile then
		configfile:write(json.encode(self.settings))
		configfile:close()
	end
end

-- Taken from TdlQ
Hooks:Add('LocalizationManagerPostInit', 'LocalizationManagerPostInit_TacticReload', function(loc)
	local language_filename

	if not language_filename then
		for _, filename in pairs( file.GetFiles(TacticReloadSettings.path .. 'loc/') ) do
			local str = filename:match( '^(.*).txt$' )
			if str and Idstring(str) and Idstring(str):key() == SystemInfo:language():key() then
				language_filename = filename
				break
			end
		end
	end

	if language_filename then
		loc:load_localization_file( TacticReloadSettings.path .. 'loc/' .. language_filename )
	end
	loc:load_localization_file( TacticReloadSettings.path .. 'loc/english.txt', false )
end)

Hooks:Add('MenuManagerInitialize', 'MenuManagerInitialize_TacticReload', function( menu_manager )
	MenuCallbackHandler.lastbullet_toggle = function( this, item )
		TacticReloadSettings.settings[ item:name() ] = item:value() == 'on'
	end

	MenuCallbackHandler.lastbullet_save = function( this, item )
		TacticReloadSettings:save()
	end

	MenuHelper:LoadFromJsonFile( TacticReloadSettings.path .. 'menu/options.txt', TacticReloadSettings, TacticReloadSettings.settings )
end)

TacticReloadSettings:load()
