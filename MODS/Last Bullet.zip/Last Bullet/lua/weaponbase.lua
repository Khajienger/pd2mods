local allow, trigger_held=
RaycastWeaponBase.start_shooting_allowed,
RaycastWeaponBase.trigger_held

function can_shoot(weapon)
	if Utils:IsInHeist() then
		return not TacticReloadSettings.settings[tweak_data.weapon[weapon.name_id].category]
		or weapon:get_ammo_remaining_in_clip() > 1
		or weapon:get_ammo_total() == 1
	end
end

function RaycastWeaponBase:start_shooting_allowed(...)
	is_reloading = managers.player:player_unit():movement():current_state():_is_reloading()
	if can_shoot(self) then
		return allow(self, ...)
	else
		if not is_reloading then
			managers.player:player_unit():movement():current_state()
			:_start_action_reload_enter(Application:time())
		end
	end
end

function RaycastWeaponBase:trigger_held(...)
	if can_shoot(self) then
		return trigger_held(self, ...)
	else
		managers.player:player_unit():movement():current_state()
		:_check_stop_shooting()
	end
end