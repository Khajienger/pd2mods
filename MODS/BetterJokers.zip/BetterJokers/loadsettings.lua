-- If this fails, only this file will error, not the whole mod
BetterJokers:Load()
