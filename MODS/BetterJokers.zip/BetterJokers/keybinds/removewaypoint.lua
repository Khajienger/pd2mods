if Utils:IsInGameState() and BJCustomWaypoints then
    BJCustomWaypoints:RemoveMyWaypoint()
end
