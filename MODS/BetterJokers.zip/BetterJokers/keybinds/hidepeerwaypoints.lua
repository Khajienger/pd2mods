if Utils:IsInGameState() and BJCustomWaypoints then
    BJCustomWaypoints:HideAllPeerWaypoints()
end
