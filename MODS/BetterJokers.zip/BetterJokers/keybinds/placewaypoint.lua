if Utils:IsInGameState() and BJCustomWaypoints then
    BJCustomWaypoints:SetMyWaypoint()
end
