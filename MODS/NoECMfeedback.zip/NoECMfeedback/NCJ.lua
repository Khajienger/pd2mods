o_damage_explosion = o_damage_explosion or CopDamage.damage_explosion
function CopDamage:damage_explosion(attack_data)
	if attack_data.variant == "stun" and attack_data.attacker_unit == managers.player:player_unit() and self._unit:brain()._logic_data.is_converted then return end
	o_damage_explosion(self, attack_data)
end